import  React,{ useState } from 'react';
import { styled } from '@mui/material/styles';
import {Paper,Card,CardMedia,Grid,Container,IconButton,Box,Divider,MenuItem,Select,InputLabel,FormControl,Button,TextField,Typography} from '@mui/material';
import TabsUnstyled from '@mui/base/TabsUnstyled';
import TabsListUnstyled from '@mui/base/TabsListUnstyled';
import TabPanelUnstyled from '@mui/base/TabPanelUnstyled';
import { buttonUnstyledClasses } from '@mui/base/ButtonUnstyled';
import TabUnstyled, { tabUnstyledClasses } from '@mui/base/TabUnstyled';
import MUIRichTextEditor from 'mui-rte';
import InvertColorsIcon from '@mui/icons-material/InvertColors'
import TableChartIcon from '@mui/icons-material/TableChart'
import { createTheme, ThemeProvider } from '@mui/material/styles'
import DeleteOutlineOutlinedIcon from '@mui/icons-material/DeleteOutlineOutlined';
import SaveAsOutlinedIcon from '@mui/icons-material/SaveAsOutlined';
import RemoveRedEyeOutlinedIcon from '@mui/icons-material/RemoveRedEyeOutlined';
import Tooltip from '@mui/material/Tooltip';
import KeyIcon from '@mui/icons-material/Key';
import VisibilityOutlinedIcon from '@mui/icons-material/VisibilityOutlined';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import Link from '@mui/material/Link';
import { Editor } from "react-draft-wysiwyg";
import { EditorState } from 'draft-js';
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";
import Breadcrumbs from '@mui/material/Breadcrumbs';
import Stack from '@mui/material/Stack';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import ReactDOM from "react-dom";
import { makeStyles } from "@material-ui/core/styles";
import Avatar from "@material-ui/core/Avatar";
import TextareaAutosize from '@mui/material/TextareaAutosize';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import LaunchOutlinedIcon from '@mui/icons-material/LaunchOutlined';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import RemoveCircleOutlineOutlinedIcon from '@mui/icons-material/RemoveCircleOutlineOutlined'
import { display, spacing } from '@mui/system';
import {alpha } from '@mui/material/styles';
import Fab from '@mui/material/Fab';
import { shadows } from '@mui/system';
import AddIcon from '@mui/icons-material/Add';
import RemoveOutlinedIcon from '@mui/icons-material/RemoveOutlined';






const useStyles = makeStyles((theme) => ({
  avatar: {
    backgroundColor: '#fff',
    border: `1px solid ${'#007bff'}`,
    // boxShadow:'0px 2px 5px 5px #007bff40',
    color: '#007bff',
    width: 30, height: 30
  }
}));


const myTheme = createTheme({})
const MyBlock = (props) => {
  return (
      <div style={{
          padding: 10,
          backgroundColor: "#ebebeb",          
      }}>
          My Block content is:
          {props.children}
      </div>
  )
}

const blue = {
  50: '#F0F7FF',
  100: '#C2E0FF',
  200: '#80BFFF',
  300: '#66B2FF',
  400: '#3399FF',
  500: '#007FFF',
  600: '#0072E5',
  700: '#0059B2',
  800: '#004C99',
  900: '#003A75',
};


const Tab = styled(TabUnstyled)`
  font-family: IBM Plex Sans, sans-serif;
  color: white;
  cursor: pointer;
  font-size: 0.875rem;
  font-weight: bold;
  background-color: transparent;
  width: 100%;
  padding: 12px 16px;
  margin: 6px 6px;
  border: none;
  border-radius: 5px;
  display: flex;
  justify-content: center;

  &:hover {
    background-color: ${blue[800]};
  }

  &:focus {
    color: #fff;
    border-radius: 3px;
    outline: 2px solid ${blue[200]};
    outline-offset: 2px;
  }

  &.${tabUnstyledClasses.selected} {
    background-color: ${blue[50]};
    color: ${blue[600]};
  }

  &.${buttonUnstyledClasses.disabled} {
    opacity: 0.5;
    cursor: not-allowed;
  }
`;

const TabPanel = styled(TabPanelUnstyled)`
  width: 100%;
  font-family: IBM Plex Sans, sans-serif;
  font-size: 0.875rem;
`;

const TabsList = styled(TabsListUnstyled)`
  min-width: 320px;
  background-color: ${blue[500]};
  border-radius: 8px;
  margin-bottom: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  align-content: space-between;
`;


const Items = styled(Paper)(({ theme }) => ({
  backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
  ...theme.typography.body2,
  padding: theme.spacing(3),
  textAlign: 'left',
  color: theme.palette.text.secondary,
  }));

 const MyTextFeild = styled(TextField)(({theme})=>({
  margin: theme.spacing(2),
  width:'97%',
 })) ;

 const ButtonBox = styled(Box)(({theme})=>({
    display: 'flex',
    justifyContent: 'space-between',
    margin: theme.spacing(1.5),
    
    

 })) ;

 const ButtonType = styled(Button)(({theme})=>({
  background:'rgb(0 109 218)',
  color:'#fff',
  '&:hover': {
    backgroundColor: 'rgb(0 109 218)',
  },
 }));

 const DeleteFab = styled(Fab)(({theme})=>({
        marginTop: theme.spacing(1),
        // marginRight: theme.spacing(2),
        background: '#f34461',
        '&:hover': {
          background: '#f34461',
        color: '#fff',
        },

 }));

export default function AddCourse() {


  const breadcrumbs = [
    <Link underline="hover" key="1" color="inherit" href="/" sx={{fontSize:'15px'}}>
      Courses
    </Link>,
    <Typography key="3" color="text.primary" sx={{fontSize:'15px'}}>
      Add Course 
    </Typography>,
  ];


  const [age10, setAge10] = React.useState('');
  const handleChange10 = (event) => {
    setAge10(event.target.value);
  };

  const [age, setAge] = React.useState('');
  const handleChange = (event) => {
   setAge(event.target.value);
  };

  const [age1, setAge1] = React.useState('');
  const handleChange1 = (event) => {
  setAge1(event.target.value);
  };

  const [age2, setAge2] = React.useState('');
  const handleChange2 = (event) => {
  setAge2(event.target.value);
  };


  const [age3, setAge3] = React.useState('');
  const handleChange3 = (event) => {
  setAge3(event.target.value);
  };


  const [age4, setAge4] = React.useState('');
  const handleChange4 = (event) => {
  setAge4(event.target.value);
 };
 const [age5, setAge5] = React.useState('');
 const handleChange5 = (event) => {
 setAge5(event.target.value);
};



 const userTemplate = {date:'', Days:'',Phone:'',Age:'',Status:'', TimeZone:'',Delivery:'',Days:'',time:'',Price:'',};
 const [users,setUsers] = useState([userTemplate]);
 const addUser =() => {
   setUsers([...users, userTemplate]);
 };
const removeUser =(index) =>{
 const filteredUsers = [...users];
 filteredUsers.splice(index, 1);
 setUsers(filteredUsers);

};

// new functiom editor

const [editorState, setEditorState] = useState(() => EditorState.createEmpty(),);
const handleEditorChange = (editorState) => {                              
  setEditorState(editorState);
}

const [editorState1, setEditorState1] = useState(() => EditorState.createEmpty(),);
const handleEditorChange1 = (editorState1) => {                              
  setEditorState1(editorState1);
}

const [editorState2, setEditorState2] = useState(() => EditorState.createEmpty(),);
const handleEditorChange2 = (editorState2) => {                              
  setEditorState2(editorState2);
}

const [editorState3, setEditorState3] = useState(() => EditorState.createEmpty(),);
const handleEditorChange3 = (editorState3) => {                              
  setEditorState3(editorState3);
}

const [editorState4, setEditorState4] = useState(() => EditorState.createEmpty(),);
const handleEditorChange4 = (editorState4) => {                              
  setEditorState4(editorState4);
}

const [editorState5, setEditorState5] = useState(() => EditorState.createEmpty(),);
const handleEditorChange5 = (editorState5) => {                              
  setEditorState5(editorState5);
}

         

  return (
<Box > 
  {/* Breadcrumbs start  */}
       <Stack spacing={2}>
          <Breadcrumbs sx={{marginBottom:'20px'}}
          separator={<NavigateNextIcon fontSize="30px" />}
          aria-label="breadcrumb"
          >
          {breadcrumbs}
          </Breadcrumbs>
       </Stack>
        {/* Breadcrumbs end  */}

  <Grid container spacing={10}>
        <Grid item xs={9} >
        {/* Course Title */}
                  <Typography sx={{ background:'#798a9ffc', width: 'max-content',borderTopRightRadius:'5px', borderTopLeftRadius:'5px',height: '28px',color:'#fff',padding:'2px 10px',boxShadow:'none !important'}}>Course Title</Typography>
                  <Card sx={{boxShadow:'none',borderRadius:'6px'}}>               
                  <MyTextFeild id="outlined-textarea" label="Course title"   size ='small'/> 
                  </Card>

                  {/*Course Overview */}

                  <Typography sx={{ marginTop:'30px',background:'#798a9ffc', width: 'max-content',borderTopRightRadius:'5px', borderTopLeftRadius:'5px',height: '28px',color:'white',padding:'2px 10px'}}>Course Overview</Typography>
                  <Grid sx={{backgroundColor:'white',padding:'20px',boxShadow:'none',width:'100%',borderRadius:'6px'}}>
                  {/* editor */}
                  <Box sx={{border:'1px solid #ccc',height:'39vh',borderRadius:'6px',width:'100%',overflowY:'auto'}}>
                    <Editor
                      editorState={editorState}
                      onEditorStateChange={handleEditorChange}
                      wrapperClassName="wrapper-class"
                      editorClassName="editor-class"
                      toolbarClassName="toolbar-class"     
                   
                    //   toolbar={{
                    //     options: ['inline', 'blockType', 'fontSize', 'fontFamily', 'list', 'textAlign', 'colorPicker', 'link', 'embedded', 'emoji', 'image', 'remove', 'history'],
                    //     inline: { inDropdown: true },
                    //     list: { inDropdown: true },
                    //     textAlign: { inDropdown: true },
                    //     link: { inDropdown: true },
                    //     history: { inDropdown: true },
                    // }}         
                  />
                    
                  </Box>
                 </Grid>
      
                      {/* Course Schedule */}
                  <Typography sx={{ marginTop:'30px',background:'#798a9ffc', width: 'max-content',borderTopRightRadius:'5px', borderTopLeftRadius:'5px',height: '28px',color:'white',padding:'2px 10px'}}>Course Schedule</Typography>
                  <Card sx={{backgroundColor:'white', paddingTop:'30px',boxShadow:'none',paddingLeft:'1px',borderRadius:'6px'}}>
                  <Container>
    {/* < Paper component ={Box} p={6}> */}
     
     {
       users.map((user, index)=>(
        <Grid container spacing={1}  key={index}>
         
        <Grid item  md={2}>
        <TextField 
                    label="Start Date"
                    type="date"
                    InputLabelProps={{
                    shrink: true,
                    }} fullWidth
                    /> 
        </Grid>
    
        <Grid item  md={1}>
        <TextField 
              label="Start Time"
              type ='time'
              fullWidth
              InputLabelProps={{
              shrink: true,
              }}
               /> 
        </Grid>

        <Grid item  md={1}>
        <FormControl fullWidth>
            <InputLabel>Zone</InputLabel>
            <Select
              value={age2}
              label="Zone"
              placeholder='type here'
              onChange={handleChange2}
            >
               <MenuItem value={20}>ET</MenuItem>
               <MenuItem value={30}>CT</MenuItem>
               <MenuItem value={40}>MT</MenuItem>
               <MenuItem value={40}>PT</MenuItem>
            </Select>
          </FormControl>
        </Grid>

        <Grid item  md={2}>
         <FormControl fullWidth>
            <InputLabel>Delivery</InputLabel>
            <Select
              value={age}
              label="Delivery"
              placeholder='type here'
              onChange={handleChange}
            >
              <MenuItem value={10}>Live Virtual Led</MenuItem>
              <MenuItem value={20}>Live Virtual Led with Assistance</MenuItem>
              <MenuItem value={30}>In-Classroom</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid item  md={2}>
     <FormControl fullWidth>
            <InputLabel>Location</InputLabel>
            <Select
              value={age5}
              label="Location"
              placeholder='type here'
              onChange={handleChange5}
            >
              <MenuItem value={10}>USA</MenuItem>
              <MenuItem value={20}>DUBAI</MenuItem>
              <MenuItem value={30}>SINGAPORE</MenuItem>
            </Select>
          </FormControl>
    </Grid>
        <Grid item  md={2}>
        <FormControl fullWidth>
            <InputLabel>Status</InputLabel>
            <Select
              value={age1}
              label="Status"
              placeholder='type here'
              onChange={handleChange1}
            >
               <MenuItem value={20}>GTR</MenuItem>
               <MenuItem value={30}>Enrolling Now</MenuItem>
               <MenuItem value={40}>Year Subscription</MenuItem>
            </Select>
          </FormControl>
        </Grid>

        <Grid item  md={2}>
        <TextField 
               id="price"
               label="Sales Price"
               placeholder='Price'
               fullWidth
               InputLabelProps={{
               shrink: true,
               }}
              />
        </Grid>


        
     <Grid item  md={2}>
     <FormControl fullWidth>
            <InputLabel>Select partner</InputLabel>
            <Select
              value={age3}
              label="Select partner"
              placeholder='type here'
              onChange={handleChange3}
            >
              <MenuItem value={10}>Live Virtual Led</MenuItem>
              <MenuItem value={20}>Live Virtual Led with Assistance</MenuItem>
              <MenuItem value={30}>In-Classroom</MenuItem>
            </Select>
          </FormControl>
    </Grid>


    <Grid item  md={1}>
     <FormControl fullWidth>
            <InputLabel>Code</InputLabel>
            <Select
              value={age4}
              label="Code"
              placeholder='type here'
              onChange={handleChange4}
            >
              <MenuItem value={10}>K1</MenuItem>
              <MenuItem value={20}>T5</MenuItem>
              <MenuItem value={30}>L10</MenuItem>
              <MenuItem value={30}>XY</MenuItem>
            </Select>
          </FormControl>
    </Grid>

    <Grid item  md={1}>
        <TextField 
              label="Days"
              placeholder='type here'
              variant="outlined" fullWidth
               /> 
        </Grid>

    <Grid item  md={2 }>
        <TextField 
               label="Partner Price"
               placeholder='Retail Price'
               InputLabelProps={{
               shrink: true,
               }}
              />
        </Grid>


    <Grid item  md={2}>
        <TextField 
               label="Zip code"
               placeholder='Code'
               InputLabelProps={{
               shrink: true,
               }}
              />
        </Grid>

      

        <Grid item  md={2}>
        <TextField 
               label="Profit"
               placeholder='price'
               InputLabelProps={{
               shrink: true,
               }}
              />
        </Grid>

        <Grid item  md={2}>
        <TextField 
               label="Retail price"
               placeholder='price'
               InputLabelProps={{
               shrink: true,
               }}
              />
        </Grid>

        <Grid container justifyContent="flex-end">
          <DeleteFab  onClick={() => removeUser(index)} size="small" color="secondary" sx={{width:'2rem',height:'0.2rem',marginBottom:'8px'}} >
        {/* <IconButton onClick={() => removeUser(index)} sx={{marginBottom:'-68px',backgroundColor:'rgba(240,115,90,0.1) !important',border:'1px solid rgba(240,115,90,0.1) !important',boxShadow:' 0 3px 5px 0 rgb(240 115 90 / 30%','&:hover': {backgroundColor:'rgba(240,115,90,1.0) !important',border:'1px solid rgba(240,115,90,1.0) !important'} }}>  */}
        <RemoveOutlinedIcon />    
        </DeleteFab> 
{/* 
        </IconButton> */}
        </Grid>
        </Grid>


       ))
     }
       <Fab size="small" color="primary"  onClick={addUser} sx={{marginTop:'-65px',backgroundColor:'#0058b0',width:'2rem',height:'0.2rem'}}>
        <AddIcon />
      </Fab>
     {/* <Button variant="contained" color="primary" onClick={addUser} sx={{marginTop:'20px'}}> Add more</Button> */}
    {/* </Paper> */}
  </Container>  
  </Card>

 {/* Who Should Attend */}
<Typography sx={{ marginTop:'30px',background:'#798a9ffc', width: 'max-content',borderTopRightRadius:'5px', borderTopLeftRadius:'5px',height: '28px',color:'white',padding:'2px 10px'}}>Who Should Attend</Typography>
<Card sx={{backgroundColor:'white', padding:'20px',boxShadow:'none',borderRadius:'6px'}}>
<Box sx={{border:'1px solid #ccc',height:'39vh',borderRadius:'6px',width:'100%'}}>
<Editor
    editorState={editorState1}
    onEditorStateChange={handleEditorChange1}
    wrapperClassName="wrapper-class"
    editorClassName="editor-class"
    toolbarClassName="toolbar-class"
  />
</Box>
</Card>
                                  
{/* Prerequisites */}
<Typography sx={{ marginTop:'30px',background:'#798a9ffc', width: 'max-content',borderTopRightRadius:'5px', borderTopLeftRadius:'5px',height: '28px',color:'white',padding:'2px 10px'}}>Prerequisites</Typography>
<Card sx={{backgroundColor:'white', padding:'20px',boxShadow:'none',borderRadius:'6px'}}>
<Box sx={{border:'1px solid #ccc',height:'39vh',borderRadius:'6px',width:'100%'}}>
<Editor
    editorState={editorState2}
    onEditorStateChange={handleEditorChange2}
    wrapperClassName="wrapper-class"
    editorClassName="editor-class"
    toolbarClassName="toolbar-class"
  />
</Box>
</Card>

 {/*objectives */}
<Typography sx={{ marginTop:'30px',background:'#798a9ffc', width: 'max-content',borderTopRightRadius:'5px', borderTopLeftRadius:'5px',height: '28px',color:'white',padding:'2px 10px'}}>objectives</Typography>
<Card sx={{backgroundColor:'white', padding:'20px',boxShadow:'none',borderRadius:'6px'}}>
  <Box sx={{border:'1px solid #ccc',height:'39vh',borderRadius:'6px',width:'100%'}}>
  <Editor
    editorState={editorState3}
    onEditorStateChange={handleEditorChange3}
    wrapperClassName="wrapper-class"
    editorClassName="editor-class"
    toolbarClassName="toolbar-class"
  />
</Box>
</Card>

 {/* Course Outline */}
<Typography sx={{ marginTop:'30px',background:'#798a9ffc', width: 'max-content',borderTopRightRadius:'5px', borderTopLeftRadius:'5px',height: '28px',color:'white',padding:'2px 10px'}}>Course Outline</Typography>
<Card sx={{backgroundColor:'white', padding:'20px',boxShadow:'none',borderRadius:'6px'}}>
<Box sx={{border:'1px solid #ccc',height:'39vh',borderRadius:'6px',width:'100%'}}>
<Editor
    editorState={editorState4}
    onEditorStateChange={handleEditorChange4}
    wrapperClassName="wrapper-class"
    editorClassName="editor-class"
    toolbarClassName="toolbar-class"
  />
</Box>
</Card>

 {/*Course Short Discription  */}
<Typography sx={{ marginTop:'30px',background:'#798a9ffc', width: 'max-content',borderTopRightRadius:'5px', borderTopLeftRadius:'5px',height: '28px',color:'white',padding:'2px 10px'}}>Course Short Discription</Typography>
<Card sx={{backgroundColor:'white', padding:'20px',boxShadow:'none',borderRadius:'6px'}}>
<Box sx={{border:'1px solid #ccc',height:'39vh',borderRadius:'6px',width:'100%'}}>
<Editor
    editorState={editorState5}
    onEditorStateChange={handleEditorChange5}
    wrapperClassName="wrapper-class"
    editorClassName="editor-class"
    toolbarClassName="toolbar-class"
  />
</Box>

</Card>
</Grid>


                <Grid xs={3} sx={{paddingLeft:'30px',paddingTop:'80px',}}>
                <Typography sx={{ background:'#798a9ffc', width: 'max-content',borderTopRightRadius:'5px', borderTopLeftRadius:'5px',height: '25px',color:'white',padding:'2px 10px'}}>Publish</Typography>
                   <Items sx={{boxShadow:'none',borderRadius:'6px'}}>
                          <Typography sx={{paddingRight:'160px' ,paddingBottom:'30px',marginTop:'20px'}} >
                          <Box sx={{display:'flex'}}>
                            <KeyIcon sx={{transform:'rotate(90deg)',marginRight:'7px',color:'#75889d'}}/>
                           Status : Draft <Link href="#" sx={{marginLeft:'10px'}}>Edit</Link></Box>  
                          </Typography>

                          <Typography sx={{paddingRight:'100px',paddingBottom:'30px'}} >
                          <Box sx={{display:'flex'}}>
                            <VisibilityOutlinedIcon sx={{marginRight:'7px',color:'#75889d'}}/>
                            Visibility :  Public <Link href="#" sx={{marginLeft:'10px'}}>Edit</Link></Box>  
                          </Typography>

                          <Typography sx={{paddingRight:'50px'}} >
                          <Box sx={{display:'flex'}}>
                          <CalendarMonthOutlinedIcon sx={{marginRight:'7px',color:'#75889d'}}/>
                          Publish : Immediately <Link href="#" sx={{marginLeft:'10px'}}>Edit</Link></Box>                
                          </Typography>
                          <Divider sx={{marginTop:'20px',marginBottom:'20px'}}/>



            {/* Right-side button groups functional start */}
            <ButtonBox>
            <ButtonType variant="outlined" startIcon={<SaveAsOutlinedIcon />} size="small" sx={{textTransform:'capitalize !important','&:hover': {backgroundColor: '#0058b0',color:'#fff',}}}> Save Draft</ButtonType> 
            <ButtonType variant="outlined" startIcon={<RemoveRedEyeOutlinedIcon />} size="small" sx={{textTransform:'capitalize !important','&:hover': {backgroundColor: '#0058b0',color:'#fff'}}}> Preview</ButtonType> 
            <ButtonType variant="outlined" startIcon={<LaunchOutlinedIcon  />} size="small" sx={{textTransform:'capitalize !important','&:hover': {backgroundColor: '#0058b0',color:'#fff'}}}> Publish</ButtonType> 
            </ButtonBox>
              {/* <Box sx={{marginTop:'38px',display:'flex',justifyContent:'space-between'}}>
                    <Button variant="outlined" startIcon={<SaveAsOutlinedIcon />} 
                          size="small" sx={{marginRight:'10px',width:'150px','&:hover': {backgroundColor: '#0058b0',color:'#fff'}}}> Save Draft
                    </Button> 
                                        
                    <Button variant="outlined" startIcon={<RemoveRedEyeOutlinedIcon />}
                          size="small" sx={{marginRight:'10px','&:hover': {backgroundColor: '#0058b0',color:'#fff'}}}>Preview
                  </Button>
                  
                    <Button sx={{color:"#fff",backgroundColor:"#007bff",'&:hover': {backgroundColor: '#0058b0'},float:'right'  }}><LaunchOutlinedIcon/> Publish 
                    </Button>
              </Box> */}
        {/* Right-side button groups functional end */}

                     </Items>


                     <Typography sx={{ marginTop:'30px',background:'#798a9ffc', width: 'max-content',borderTopRightRadius:'5px', borderTopLeftRadius:'5px',height: '28px',color:'white',padding:'2px 10px'}}>Categories</Typography>
                     <Items sx={{height:'170px',boxShadow:'none',borderRadius:'6px'}}>
                            <TabsUnstyled defaultValue={0}>
                                  <TabsList>
                                      <Tab sx={{}}>All Categories</Tab>
                                      <Tab>Most used</Tab>
                                  </TabsList>
                                    <TabPanel value={0}>All Categories</TabPanel>
                                    <TabPanel value={1}>Most Used</TabPanel>
                            </TabsUnstyled>
                     </Items>

                          {/* Course Images */}
                     <Typography sx={{ marginTop:'30px',background:'#798a9ffc', width: 'max-content',borderTopRightRadius:'5px', borderTopLeftRadius:'5px',height: '28px',color:'white',padding:'2px 10px'}}>Feature Images</Typography>
                       <Items sx={{height:'400px',boxShadow:'none',borderRadius:'6px'}}>
                           <Button variant ="outlined" sx={{marginBottom:'30px'}}>Add NEW</Button>
                           <Card sx={{ border: '1px dashed grey', width:'80%',height:'70%',marginLeft:'35px' }}>
                              <CardMedia
                                      component="img"
                                      alt="green iguana"
                                      height="140"
                                      image="/static/images/cards/contemplative-reptile.jpg"
                                    />
                          </Card>
                     </Items>

                     {/* Course Tag */}
                     <Typography sx={{ marginTop:'30px',background:'#798a9ffc', width: 'max-content',borderTopRightRadius:'5px', borderTopLeftRadius:'5px',height: '25px',color:'white',padding:'2px 10px'}}>Course Tags</Typography>
                     <Items sx={{height:'120px',boxShadow:'none',borderRadius:'6px'}}>
                            <FormControl  sx={{ width:'100%' }}>
                                <InputLabel id="demo-simple-select-label">Course Tags</InputLabel>
                                <Select
                                  labelId="demo-simple-select-label"
                                  id="demo-simple-select"
                                  value={age10}
                                  label="Course Tags"
                                  onChange={handleChange10}
                                >
                                  <MenuItem value={50}>Eastern Time</MenuItem>
                                  <MenuItem value={60}>Central Time</MenuItem>
                                  <MenuItem value={70}>Mountain Time</MenuItem>
                                  <MenuItem value={80}>Pacific Time</MenuItem>
                                </Select>
                        </FormControl>
                  </Items>
        
            {/* Add Product Gallery images */}
                     <Typography sx={{ marginTop:'30px',background:'#798a9ffc', width: 'max-content',borderTopRightRadius:'5px', borderTopLeftRadius:'5px',height: '28px',color:'white',padding:'2px 10px'}}>Course Gallery</Typography>
                     <Items sx={{height:'120px',boxShadow:'none',borderRadius:'6px'}}>
                      <Button variant ="outlined" sx={{marginBottom:'30px',width:'100%',height:'60px'}}>Add Product Gallery images</Button>   
                     </Items>
                 </Grid> 
      </Grid>
      </Box>
        );
        }

