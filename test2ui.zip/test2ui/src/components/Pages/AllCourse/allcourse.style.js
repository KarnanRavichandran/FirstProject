import { styled } from '@mui/material/styles';

export const test = styled({
    root: {
      border: "1px solid red",
      padding: 10,
      background:'#ccc'
    },
  });