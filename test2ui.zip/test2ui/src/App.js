import React from 'react';
import Knowlogy from './components/Knowlogy/knowlogy';
import './App.css';

function App() {
  return (
    <div className="App" >    
      <Knowlogy/> 
    </div>
  );
}

export default App;